#ifndef AHISTORY_H
#define AHISTORY_H

#include "types.h"

/*
class ACommand : public Poly<uint>
{
    //command abstraction on string or int[] set or both
public:
    //should just cover the option of all possible actions to editing

    std::string to_s();



};

class AHistory : public Poly<ACommand>
{
public:
    AHistory();

    //operator +=
    //operator =
    //clean
    //undo
    //redo
    //to raw data(best way to store values - in fact - controls of versions in base form)

    std::string to_s();


};
*/ //replace from other - here mast be tab commands

#endif // AHISTORY_H
